-- ============================================================================
--  UCC AgCommand — table setup for the (shared) Cecelia Supabase project
--
--  Run this ONCE in the Supabase SQL editor:
--     Dashboard  ->  SQL Editor  ->  New query  ->  paste  ->  Run
--
--  What it does:
--    * Creates a UCC-only copy of every table the app uses, prefixed "ucc_".
--    * Each copy clones the STRUCTURE of the matching Cecelia table
--      (columns, types, defaults, keys) — but NONE of its data.
--    * Opens each ucc_ table to the project's anon/publishable key so the
--      app can read + write (same access model the Cecelia tables use).
--
--  Result: UCC and Cecelia live side-by-side in the same project without
--  ever touching each other's rows.
-- ============================================================================

do $$
declare
  t text;
  tables text[] := array[
    'fields','activities','issues','lots','assigned_tasks','check_ins',
    'past_plantings','loads','pallets','pack_styles','compliance_docs',
    'direct_employees','flcs','flc_certifications','water_sources','reminder_snoozes'
  ];
begin
  foreach t in array tables loop
    -- Skip if the Cecelia source table doesn't exist (feature never used)
    if to_regclass('public.'||t) is null then
      raise notice 'source table public.% not found — skipping', t;
      continue;
    end if;

    -- Structural clone, no data
    execute format(
      'create table if not exists public.%I (like public.%I including all)',
      'ucc_'||t, t
    );

    -- Enable RLS and allow the anon/authenticated roles full access (demo)
    execute format('alter table public.%I enable row level security', 'ucc_'||t);
    execute format(
      'drop policy if exists ucc_all on public.%I', 'ucc_'||t
    );
    execute format(
      'create policy ucc_all on public.%I for all to anon, authenticated using (true) with check (true)',
      'ucc_'||t
    );
  end loop;
end $$;

-- ---------------------------------------------------------------------------
--  Storage bucket for UCC compliance-doc uploads (optional feature).
--  Safe to run repeatedly.
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('ucc-compliance-docs', 'ucc-compliance-docs', true)
on conflict (id) do nothing;

-- Allow read/write on that bucket via the anon/publishable key (demo).
drop policy if exists ucc_docs_all on storage.objects;
create policy ucc_docs_all on storage.objects
  for all to anon, authenticated
  using (bucket_id = 'ucc-compliance-docs')
  with check (bucket_id = 'ucc-compliance-docs');

-- Done. Reload the UCC app — it will seed its 35 blocks into ucc_fields
-- on first load, and use ucc_* for everything after.
