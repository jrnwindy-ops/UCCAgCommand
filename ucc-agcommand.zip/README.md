# UCC — AgCommand Field Operations

A single-page field-operations app for UCC's citrus blocks: an interactive
map + list of blocks, per-block detail (variety, rootstock, tree spacing,
trees/acre, row spacing, acreage, irrigation status), activity logging,
reminders, and reporting. Bilingual (English / Spanish).

Everything lives in one self-contained `index.html` — all libraries
(Leaflet, Supabase, etc.) load from CDNs, so there is **no build step**.

## Run it

Open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8080
# then visit http://localhost:8080
```

## Deploy

Because it's a static single file, any static host works:

- **Netlify / Vercel / Cloudflare Pages** — point the project at this repo;
  no build command, publish directory is the repo root.
- **GitHub Pages** — Settings → Pages → deploy from the `main` branch, root.

## Data / backend (Supabase)

The app is wired to a Supabase project for persistence and sync. On first
load it seeds the 35 blocks into the database; after that the database is
the source of truth.

To set up the tables, run **`ucc_supabase_setup.sql`** once in the Supabase
SQL editor. It creates a UCC-only, `ucc_`-prefixed copy of each table so
this app never collides with any other app in the same project.

The connection uses Supabase's **publishable (anon) key**, which is designed
to live in client-side code. Access is currently governed by wide-open
row-level-security policies (fine for a demo). If this repo is public and
you want the data locked down, tighten those RLS policies in Supabase.

Credentials live near the top of `index.html`:

```js
const SUPABASE_URL = '...';
const SUPABASE_KEY = '...';
```

Swap those two lines to move the app to a different Supabase project.

## Files

- `index.html` — the entire application
- `ucc_supabase_setup.sql` — one-time table + bucket setup for Supabase
